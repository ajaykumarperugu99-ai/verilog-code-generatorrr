# Deploying to Render

## Option A — Blueprint (`render.yaml`)

1. Push this repository to GitHub.
2. In the Render dashboard: **New +** → **Blueprint** → connect the
   GitHub repo. Render reads `render.yaml` and proposes the
   `langgraph-to-verilog` web service automatically.
3. Before the first deploy, open the service's **Environment** tab and
   set `GEMINI_API_KEY` (the blueprint marks it `sync: false`
   specifically so it is never committed to the repo — you must set it
   in the dashboard).
4. Click **Apply** / **Create Web Service**.

## Option B — Manual web service

1. **New +** → **Web Service** → connect your GitHub repo.
2. Runtime: **Python 3**.
3. Build command:
   ```
   pip install -r requirements.txt
   ```
4. Start command:
   ```
   uvicorn main:app --host 0.0.0.0 --port $PORT
   ```
   Render injects `$PORT`; `main.py`'s `if __name__ == "__main__"`
   block also reads `PORT` for parity when run directly.
5. Under **Environment**, add:
   | Key | Value |
   |---|---|
   | `GEMINI_API_KEY` | your key (leave the app working without it if you'd rather ship static-analysis-only) |
   | `GEMINI_MODEL` | `gemini-1.5-flash` (optional, this is the default) |
   | `ENVIRONMENT` | `production` |
6. Click **Create Web Service**. Render builds and deploys; your app
   is live at `https://<service-name>.onrender.com`.

## Verifying the deployment

- `GET /api/health` should return `{"status":"ok","gemini_configured":true|false}`.
- Load the site, click **Load reference example**, then **Generate
  Verilog** — you should see RTL/Testbench/Explanation tabs populate
  within a few seconds.
- If `gemini_configured` is `false` and you paste a workflow whose
  graph the static analyzer can't find, the app returns a clear `422`
  error rather than crashing — this is expected behavior, not a bug,
  per the "Why this is possible" section of the README.

## Troubleshooting: `metadata-generation-failed` / `pydantic-core`

Render's default Python version for new services is whatever the
latest release was when the service was created, which can be newer
than the pinned dependency versions here have prebuilt wheels for.
When that happens, pip falls back to compiling `pydantic-core` from
source, which needs a Rust toolchain Render's build environment
doesn't provide, and the build fails.

Fix: pin the Python version, either by setting the `PYTHON_VERSION`
environment variable (already done for you in `render.yaml`, value
`3.11.9`) or via the `.python-version` file at the repo root (also
included). If you're on a manually-configured Web Service rather than
the blueprint, add `PYTHON_VERSION=3.11.9` under Environment yourself
and redeploy. Do **not** use `runtime.txt` — that's a Heroku
convention and Render ignores it.

## Notes

- Nothing in `.gitignore`'s exclusions (`.env`, `generated/*`) should
  ever be pushed; Render environment variables are the only place the
  real `GEMINI_API_KEY` should live.
- The free Render plan spins down on inactivity; the first request
  after idling will be slow to respond while the instance restarts.
