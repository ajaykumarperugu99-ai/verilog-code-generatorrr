# Agentic AI: LangGraph to Verilog Generator

A web app that analyzes a **LangGraph / LangChain** workflow's control flow
(nodes, edges, conditional routing) and converts it into a synthesizable
**Verilog-2001** FSM, plus a testbench and a plain-language explanation of
the resulting hardware architecture.

```
Python (LangGraph StateGraph)  --analyze-->  workflow graph (nodes/edges)
                                                    |
                                                    v
                                       FSM plan (states, transitions)
                                                    |
                                                    v
                         agent_controller.v + per-stage interfaces + agent_top.v + testbench
```

## Why this is possible, and what it deliberately does NOT do

A LangGraph workflow's **control flow** — which stage runs after which,
and which decision routes where — is ordinary Python calls
(`add_node`, `add_edge`, `add_conditional_edges`) that can be parsed
exactly with Python's `ast` module, with no need to run untrusted code
and no dependence on an LLM correctly reading the source.

What a LangGraph node usually *does* internally — call an LLM, run
arbitrary Python, hit the network — **cannot** be turned into ordinary
synthesizable digital logic. This project does not pretend otherwise:
every such node is represented as a black-box handshake interface
(`*_start` / `*_done`, or `*_eval` / `*_valid` / `*_sel` for decisions)
that a real SoC would wire up to an embedded core, a co-processor bus,
or external software. The generated `WORKFLOW_EXPLANATION.md` and the
"Not synthesized as RTL" panel in the UI list exactly which parts of
your workflow fall into this category, for every graph you paste in —
not just the bundled reference example.

## Architecture

```
main.py                     FastAPI app: routes + orchestration
app/
  config.py                 Server-side settings (GEMINI_API_KEY, etc.)
  models.py                 Pydantic request/response schemas
  workflow_analyzer.py      AST-based LangGraph control-flow extractor
  gemini_client.py          Optional LLM fallback + explanation text
  verilog_generator.py      WorkflowAnalysis -> Verilog-2001 RTL + testbench
templates/index.html        Single-page UI
static/css/style.css        UI styling
static/js/app.js            UI logic (calls /api/generate, /api/download-all)
examples/
  reference_langgraph.py    The task-input/developer/tester/manager/archiver
                             reference workflow this project was built against
  generated_verilog/        Verilog files generated FROM that reference workflow,
                             checked into the repo so you have a concrete example
                             without running the server
```

### Backend flow (`POST /api/generate`)

1. **Validate** the request body (`source_code`, optional `requirements`).
2. **Analyze**: `app/workflow_analyzer.py` parses the Python source with
   `ast`, locates a `StateGraph(...)` construction, and recovers its
   nodes, edges, conditional-routing tables, and `TypedDict` state
   fields. Any call that indicates non-synthesizable behavior (LLM
   client construction, `.invoke(...)`, `exec`, `subprocess`, etc.) is
   flagged as an "unsupported" component.
3. **LLM fallback** (only if `GEMINI_API_KEY` is set *and* step 2 found
   no `StateGraph` at all): `app/gemini_client.py` asks Gemini to
   extract the same JSON structure from the raw source as a best-effort
   fallback for graphs that use a pattern the static analyzer doesn't
   recognize.
4. **Generate**: `app/verilog_generator.py` deterministically maps the
   recovered graph onto FSM states (`IDLE` → your entry node → … →
   `DONE`, plus an always-present `ERROR` state), emits
   `agent_controller.v`, one interface module per stage,
   `agent_top.v`, and `tb_agent_top.v`.
5. **Explain**: a deterministic explanation is always generated; if
   Gemini is configured, it's replaced with an LLM-written one (never
   blocks the request if that call fails).
6. Return structured JSON: `{ success, analysis, files[], explanation,
   unsupported[] }`. No internal prompts, stack traces, or LLM
   scratch output are ever included in the response.

If step 2 finds nothing **and** Gemini isn't configured, the API
returns a `422` with a clear, specific error message — it never
fabricates a generic/fake workflow.

## Running locally

```bash
python3 -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env
# edit .env and set GEMINI_API_KEY if you want LLM-assisted analysis
# (the app works without it — see "Why this is possible" above)

uvicorn main:app --reload
# open http://127.0.0.1:8000
```

Click **"Load reference example"** in the UI to populate the input
with the bundled reference workflow, or paste your own LangGraph file.

## Testing the generated RTL

The bundled example output is already generated and checked in at
`examples/generated_verilog/`. If you have
[Icarus Verilog](https://github.com/steveicarus/iverilog) installed:

```bash
cd examples/generated_verilog
iverilog -g2001 -o sim.out agent_controller.v developer_interface.v \
  tester_interface.v manager_interface.v task_input_interface.v \
  archiver_interface.v agent_top.v tb_agent_top.v
vvp sim.out
```

This repository's generated example has been reviewed line-by-line for
Verilog-2001 syntax and cross-module port-name consistency (every
signal connected in `agent_top.v` matches a declared port on the
module it connects to, and vice versa), but it has **not** been
compiled with a simulator in this environment — do not take "should
compile" as "has been compiled"; run the command above yourself to
confirm on your machine.

## API

| Route | Method | Purpose |
|---|---|---|
| `/` | GET | Serves the UI |
| `/api/health` | GET | `{status, gemini_configured}` |
| `/api/generate` | POST | `{source_code, requirements}` → `{success, analysis, files, explanation, unsupported}` |
| `/api/download-all` | POST | Same input, returns a `.zip` of every generated file |

## Deployment

See [`docs/DEPLOYMENT.md`](docs/DEPLOYMENT.md) for Render instructions.

## Limitations

- Only the **control-flow graph** of a LangGraph workflow is converted
  to hardware. Anything data-dependent (what an LLM actually returns,
  what arbitrary executed Python actually does) is out of scope for
  RTL synthesis by definition, and is surfaced as an external
  handshake interface instead — see "Why this is possible" above.
- `add_conditional_edges` calls whose routing dictionary isn't a
  literal `dict` in the source (e.g. built dynamically at runtime)
  can't be resolved by static analysis; the analyzer reports this as a
  warning, and (if configured) falls back to the LLM extractor.
- The AST analyzer looks for the `StateGraph` with the most `add_node`
  calls in the file, so a file that defines multiple graphs will
  convert whichever one is largest.
