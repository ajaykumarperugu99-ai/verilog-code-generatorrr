(() => {
  const sourceInput = document.getElementById('source-input');
  const reqsInput = document.getElementById('requirements-input');
  const generateBtn = document.getElementById('generate-btn');
  const generateLabel = document.getElementById('generate-label');
  const generateSpinner = document.getElementById('generate-spinner');
  const clearBtn = document.getElementById('clear-btn');
  const loadExampleBtn = document.getElementById('load-example-btn');
  const errorBox = document.getElementById('error-box');
  const tabsEl = document.getElementById('tabs');
  const fileTabsEl = document.getElementById('file-tabs');
  const outputCode = document.getElementById('output-code');
  const outputView = document.getElementById('output-view');
  const copyBtn = document.getElementById('copy-btn');
  const downloadBtn = document.getElementById('download-btn');
  const downloadAllBtn = document.getElementById('download-all-btn');
  const unsupportedBox = document.getElementById('unsupported-box');
  const unsupportedList = document.getElementById('unsupported-list');

  let lastResult = null;   // full API response
  let activeGroup = 'rtl'; // 'rtl' | 'testbench' | 'doc'
  let activeFile = null;   // GeneratedFile currently shown

  const GROUPS = [
    { key: 'rtl', label: 'RTL' },
    { key: 'testbench', label: 'Testbench' },
    { key: 'doc', label: 'Explanation' },
  ];

  function setError(msg) {
    if (!msg) {
      errorBox.hidden = true;
      errorBox.textContent = '';
      return;
    }
    errorBox.hidden = false;
    errorBox.textContent = msg;
  }

  function setBusy(busy) {
    generateBtn.disabled = busy;
    generateSpinner.hidden = !busy;
    generateLabel.textContent = busy ? 'Generating…' : 'Generate Verilog';
  }

  function renderTabs() {
    tabsEl.innerHTML = '';
    GROUPS.forEach(g => {
      const files = (lastResult?.files || []).filter(f => f.kind === g.key);
      if (files.length === 0) return;
      const btn = document.createElement('button');
      btn.className = 'tab-btn' + (g.key === activeGroup ? ' active' : '');
      btn.textContent = `${g.label} (${files.length})`;
      btn.type = 'button';
      btn.addEventListener('click', () => {
        activeGroup = g.key;
        activeFile = files[0];
        renderTabs();
        renderFileChips();
        renderOutput();
      });
      tabsEl.appendChild(btn);
    });
  }

  function renderFileChips() {
    const files = (lastResult?.files || []).filter(f => f.kind === activeGroup);
    if (files.length <= 1) {
      fileTabsEl.hidden = true;
      fileTabsEl.innerHTML = '';
      return;
    }
    fileTabsEl.hidden = false;
    fileTabsEl.innerHTML = '';
    files.forEach(f => {
      const chip = document.createElement('button');
      chip.className = 'file-chip' + (activeFile === f ? ' active' : '');
      chip.textContent = f.filename;
      chip.type = 'button';
      chip.addEventListener('click', () => {
        activeFile = f;
        renderFileChips();
        renderOutput();
      });
      fileTabsEl.appendChild(chip);
    });
  }

  function renderOutput() {
    if (!activeFile) {
      outputCode.textContent = '// Generated RTL, testbench, and workflow explanation will appear here\n// once you generate Verilog from a LangGraph workflow.';
      outputView.classList.remove('markdown-view');
      copyBtn.disabled = true;
      downloadBtn.disabled = true;
      return;
    }
    outputCode.textContent = activeFile.content;
    outputView.classList.toggle('markdown-view', activeFile.kind === 'doc');
    copyBtn.disabled = false;
    downloadBtn.disabled = false;
  }

  function renderUnsupported() {
    const items = lastResult?.unsupported || [];
    if (items.length === 0) {
      unsupportedBox.hidden = true;
      return;
    }
    unsupportedBox.hidden = false;
    unsupportedList.innerHTML = '';
    items.forEach(u => {
      const li = document.createElement('li');
      li.innerHTML = `<b>${escapeHtml(u.name)}</b> — ${escapeHtml(u.reason)}`;
      unsupportedList.appendChild(li);
    });
  }

  function escapeHtml(s) {
    const div = document.createElement('div');
    div.textContent = s;
    return div.innerHTML;
  }

  async function generate() {
    setError(null);
    const source_code = sourceInput.value.trim();
    if (!source_code) {
      setError('Paste LangGraph or LangChain source code first.');
      return;
    }

    setBusy(true);
    try {
      const resp = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ source_code, requirements: reqsInput.value.trim() }),
      });
      const data = await resp.json();

      if (!resp.ok || !data.success) {
        setError(data.error || 'Generation failed for an unknown reason.');
        lastResult = null;
        activeFile = null;
        renderTabs();
        renderFileChips();
        renderOutput();
        renderUnsupported();
        return;
      }

      lastResult = data;
      activeGroup = 'rtl';
      const rtlFiles = data.files.filter(f => f.kind === 'rtl');
      activeFile = rtlFiles[0] || data.files[0] || null;
      renderTabs();
      renderFileChips();
      renderOutput();
      renderUnsupported();
      downloadAllBtn.disabled = false;
    } catch (err) {
      setError('Network or server error: ' + err.message);
    } finally {
      setBusy(false);
    }
  }

  async function downloadAll() {
    const source_code = sourceInput.value.trim();
    if (!source_code) return;
    downloadAllBtn.disabled = true;
    try {
      const resp = await fetch('/api/download-all', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ source_code, requirements: reqsInput.value.trim() }),
      });
      if (!resp.ok) {
        const data = await resp.json().catch(() => ({}));
        setError(data.error || 'Could not build the download archive.');
        return;
      }
      const blob = await resp.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'langgraph_to_verilog_output.zip';
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    } finally {
      downloadAllBtn.disabled = false;
    }
  }

  function downloadCurrent() {
    if (!activeFile) return;
    const blob = new Blob([activeFile.content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = activeFile.filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  }

  async function copyCurrent() {
    if (!activeFile) return;
    try {
      await navigator.clipboard.writeText(activeFile.content);
      const original = copyBtn.textContent;
      copyBtn.textContent = 'Copied';
      setTimeout(() => { copyBtn.textContent = original; }, 1200);
    } catch {
      setError('Clipboard access was blocked by the browser; select and copy the code manually.');
    }
  }

  function clearAll() {
    sourceInput.value = '';
    reqsInput.value = '';
    setError(null);
    lastResult = null;
    activeFile = null;
    activeGroup = 'rtl';
    renderTabs();
    renderFileChips();
    renderOutput();
    renderUnsupported();
    downloadAllBtn.disabled = true;
  }

  const REFERENCE_EXAMPLE = `from typing import TypedDict, List, Literal
from langgraph.graph import StateGraph, START, END
from langchain_google_genai import ChatGoogleGenerativeAI

llm = ChatGoogleGenerativeAI(model="gemini-1.5-flash", temperature=0)


class CrewState(TypedDict):
    messages: List[str]
    next_step: str
    code: str
    report: str


def run_python_code(code: str) -> str:
    import io, contextlib
    buf = io.StringIO()
    try:
        with contextlib.redirect_stdout(buf):
            exec(code, {})
        return buf.getvalue() or "OK"
    except Exception as exc:
        return f"ERROR: {exc}"


def generate_test_cases(code: str) -> str:
    response = llm.invoke(f"Generate test cases for:\\n{code}")
    return response.content


def task_input_node(state: CrewState) -> CrewState:
    if state.get("next_step") == "exit":
        return {**state, "next_step": "exit"}
    return {**state, "next_step": "developer"}


def real_time_developer(state: CrewState) -> CrewState:
    return {**state, "next_step": "tester"}


def real_time_tester(state: CrewState) -> CrewState:
    result = run_python_code(state["code"])
    tests = generate_test_cases(state["code"])
    report = f"run={result}\\ntests={tests}"
    return {**state, "report": report, "next_step": "manager_decision"}


def manager_decision_node(state: CrewState) -> CrewState:
    decision = "store" if "ERROR" not in state["report"] else "another"
    return {**state, "next_step": decision}


def archiver_node(state: CrewState) -> CrewState:
    return {**state, "next_step": "done"}


def route_from_task_input(state: CrewState) -> Literal["continue", "exit"]:
    return "exit" if state.get("next_step") == "exit" else "continue"


def route_from_manager(state: CrewState) -> Literal["store", "another"]:
    return state["next_step"]


graph = StateGraph(CrewState)
graph.add_node("task_input", task_input_node)
graph.add_node("developer", real_time_developer)
graph.add_node("tester", real_time_tester)
graph.add_node("manager_decision", manager_decision_node)
graph.add_node("archiver", archiver_node)

graph.add_edge(START, "task_input")
graph.add_conditional_edges("task_input", route_from_task_input, {"continue": "developer", "exit": END})
graph.add_edge("developer", "tester")
graph.add_edge("tester", "manager_decision")
graph.add_conditional_edges("manager_decision", route_from_manager, {"store": "archiver", "another": "task_input"})
graph.add_edge("archiver", END)

app = graph.compile()
`;

  loadExampleBtn.addEventListener('click', () => {
    sourceInput.value = REFERENCE_EXAMPLE;
    setError(null);
  });

  generateBtn.addEventListener('click', generate);
  clearBtn.addEventListener('click', clearAll);
  copyBtn.addEventListener('click', copyCurrent);
  downloadBtn.addEventListener('click', downloadCurrent);
  downloadAllBtn.addEventListener('click', downloadAll);

  renderOutput();
})();
