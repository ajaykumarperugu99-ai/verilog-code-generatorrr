"""
Static analysis of LangGraph / LangChain source code.

Design note (why AST, not "just ask the LLM"):
LangGraph's control-flow graph -- nodes, edges, conditional routing -- is
declared in ordinary Python statements (`add_node`, `add_edge`,
`add_conditional_edges`) that can be recovered *exactly* with the `ast`
module, without executing untrusted user code and without depending on
an LLM's ability to read code correctly. We treat AST extraction as the
source of truth for graph topology, and use the LLM (when configured)
only for the parts that are genuinely ambiguous in free-form code:
human-readable descriptions, and a best-effort fallback when a graph
uses a pattern the static analyzer does not recognize.

Anything that is not graph topology -- LLM calls, arbitrary Python
execution, file/network I/O -- is flagged as an "unsupported" component:
those are exactly the parts that cannot become synthesizable RTL and
must be represented as external interfaces (see verilog_generator.py).
"""

from __future__ import annotations

import ast
from dataclasses import dataclass, field

from app.models import WorkflowAnalysis, WorkflowNode, WorkflowEdge, UnsupportedComponent

START_NAMES = {"START", "__start__"}
END_NAMES = {"END", "__end__"}

# Calls that indicate a node depends on something that cannot be
# synthesized as ordinary digital logic.
EXTERNAL_CALL_MARKERS = {
    "invoke": "LLM inference call (Gemini / ChatGoogleGenerativeAI)",
    "exec": "Dynamic Python execution",
    "eval": "Dynamic Python execution",
    "run_python_code": "Runs arbitrary Python code",
    "generate_test_cases": "LLM-generated test scenarios",
    "subprocess": "External process invocation",
    "requests": "Network I/O",
}


@dataclass
class _RawGraph:
    graph_var: str | None = None
    state_type: str | None = None
    nodes: dict[str, str] = field(default_factory=dict)  # name -> source func name
    edges: list[WorkflowEdge] = field(default_factory=list)
    decision_nodes: set[str] = field(default_factory=set)
    unsupported: dict[str, str] = field(default_factory=dict)  # name -> reason
    warnings: list[str] = field(default_factory=list)


def _name_of(node: ast.AST) -> str | None:
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        return node.attr
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value
    return None


def _literal_or_name(node: ast.AST) -> str | None:
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value
    return _name_of(node)


class _GraphVisitor(ast.NodeVisitor):
    """Finds StateGraph(...) construction and its .add_node/.add_edge/
    .add_conditional_edges calls, anywhere in the module."""

    def __init__(self) -> None:
        self.graphs: dict[str, _RawGraph] = {}
        self.state_fields: dict[str, list[str]] = {}
        self.function_bodies: dict[str, ast.FunctionDef] = {}

    # -- collect TypedDict-style state classes -----------------------------
    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        fields = []
        for stmt in node.body:
            if isinstance(stmt, ast.AnnAssign) and isinstance(stmt.target, ast.Name):
                fields.append(stmt.target.id)
        if fields:
            self.state_fields[node.name] = fields
        self.generic_visit(node)

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self.function_bodies[node.name] = node
        self.generic_visit(node)

    # -- find `X = StateGraph(SomeState)` -----------------------------------
    def visit_Assign(self, node: ast.Assign) -> None:
        if (
            isinstance(node.value, ast.Call)
            and _name_of(node.value.func) == "StateGraph"
            and len(node.targets) == 1
            and isinstance(node.targets[0], ast.Name)
        ):
            var_name = node.targets[0].id
            state_type = None
            if node.value.args:
                state_type = _name_of(node.value.args[0])
            self.graphs[var_name] = _RawGraph(graph_var=var_name, state_type=state_type)
        self.generic_visit(node)

    # -- find graph.add_node / add_edge / add_conditional_edges -------------
    def visit_Expr(self, node: ast.Expr) -> None:
        # graph.add_node(...) / add_edge(...) / add_conditional_edges(...)
        # are always used as bare expression statements, so handling them
        # only here (and not also in a generic Call visitor) avoids
        # double-counting when generic_visit later walks into the Call.
        self._maybe_handle_call(node.value)
        self.generic_visit(node)

    def _maybe_handle_call(self, node: ast.AST) -> None:
        if not isinstance(node, ast.Call) or not isinstance(node.func, ast.Attribute):
            return
        recv = node.func.value
        method = node.func.attr
        if not isinstance(recv, ast.Name) or recv.id not in self.graphs:
            return
        g = self.graphs[recv.id]

        if method == "add_node" and len(node.args) >= 2:
            node_name = _literal_or_name(node.args[0])
            func_name = _name_of(node.args[1])
            if node_name:
                g.nodes[node_name] = func_name or node_name

        elif method == "add_edge" and len(node.args) >= 2:
            src = _literal_or_name(node.args[0]) or "START"
            dst = _literal_or_name(node.args[1]) or "END"
            src = "START" if src in START_NAMES else src
            dst = "END" if dst in END_NAMES else dst
            g.edges.append(WorkflowEdge(source=src, target=dst, condition=None))

        elif method == "add_conditional_edges" and len(node.args) >= 2:
            src = _literal_or_name(node.args[0]) or "?"
            g.decision_nodes.add(src)
            mapping_node = node.args[2] if len(node.args) >= 3 else None
            if isinstance(mapping_node, ast.Dict):
                for k, v in zip(mapping_node.keys, mapping_node.values):
                    cond = _literal_or_name(k) if k else None
                    target = _literal_or_name(v) or "?"
                    target = "END" if target in END_NAMES else target
                    g.edges.append(WorkflowEdge(source=src, target=target, condition=cond))
            else:
                g.warnings.append(
                    f"add_conditional_edges for '{src}' has no literal mapping dict; "
                    "routing targets could not be statically resolved."
                )


def _scan_unsupported(tree: ast.Module) -> dict[str, str]:
    """Walk every call in the module and flag calls that indicate
    non-synthesizable behavior (LLM calls, exec, subprocess, network)."""
    found: dict[str, str] = {}
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            name = None
            if isinstance(node.func, ast.Attribute):
                name = node.func.attr
            elif isinstance(node.func, ast.Name):
                name = node.func.id
            if name in EXTERNAL_CALL_MARKERS:
                found[name] = EXTERNAL_CALL_MARKERS[name]
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
            if node.func.id in ("ChatGoogleGenerativeAI", "ChatOpenAI", "ChatAnthropic"):
                found[node.func.id] = "LLM client instantiation (external inference service)"
    return found


def analyze_source_ast(source_code: str) -> tuple[_RawGraph | None, dict[str, list[str]], list[str]]:
    """Returns (best graph found, state field map, module-level warnings)."""
    try:
        tree = ast.parse(source_code)
    except SyntaxError as exc:
        return None, {}, [f"Python syntax error at line {exc.lineno}: {exc.msg}"]

    visitor = _GraphVisitor()
    visitor.visit(tree)

    unsupported = _scan_unsupported(tree)

    if not visitor.graphs:
        return None, visitor.state_fields, ["No StateGraph(...) construction found in source."]

    # Prefer the graph with the most nodes (handles files defining helpers).
    best_var, best_graph = max(visitor.graphs.items(), key=lambda kv: len(kv[1].nodes))
    best_graph.unsupported = unsupported
    return best_graph, visitor.state_fields, []


def _classify_node(name: str, raw: _RawGraph) -> str:
    if name in START_NAMES:
        return "entry"
    if name in END_NAMES:
        return "terminal"
    if name in raw.decision_nodes:
        return "decision"
    return "task"


def build_analysis(source_code: str) -> WorkflowAnalysis:
    raw, state_fields, warnings = analyze_source_ast(source_code)

    if raw is None:
        # Nothing usable found statically. Return an empty-but-valid
        # analysis; app/gemini_client.py may be used by main.py to
        # attempt an LLM-assisted fallback before giving up entirely.
        return WorkflowAnalysis(
            graph_variable=None,
            state_fields=[],
            nodes=[],
            edges=[],
            decision_nodes=[],
            unsupported=[],
            analysis_method="ast",
            warnings=warnings or ["Could not locate a LangGraph StateGraph in the supplied source."],
        )

    all_node_names = set(raw.nodes) | {"START", "END"}
    for e in raw.edges:
        all_node_names.add(e.source)
        all_node_names.add(e.target)

    nodes = [
        WorkflowNode(
            name=n,
            kind=_classify_node(n, raw),
            description=f"maps to function `{raw.nodes.get(n, n)}`" if n in raw.nodes else "",
        )
        for n in sorted(all_node_names, key=lambda x: (x not in START_NAMES, x in END_NAMES, x))
    ]

    unsupported = [
        UnsupportedComponent(name=k, reason=v) for k, v in sorted(raw.unsupported.items())
    ]

    fields = state_fields.get(raw.state_type, []) if raw.state_type else []

    return WorkflowAnalysis(
        graph_variable=raw.graph_var,
        state_fields=fields,
        nodes=nodes,
        edges=raw.edges,
        decision_nodes=sorted(raw.decision_nodes),
        unsupported=unsupported,
        analysis_method="ast",
        warnings=warnings + raw.warnings,
    )
