"""
Server-side configuration.

The Gemini API key is read only from the environment. It is never sent
to the frontend, never logged, and never accepted as a request parameter
from the client. If it is missing, LLM-assisted analysis degrades
gracefully to the deterministic AST-based analyzer (see
app/workflow_analyzer.py) and the API reports this clearly rather than
crashing.
"""

import os
from dataclasses import dataclass


@dataclass(frozen=True)
class Settings:
    gemini_api_key: str | None
    gemini_model: str
    max_source_chars: int
    generated_dir: str
    environment: str

    @property
    def gemini_configured(self) -> bool:
        return bool(self.gemini_api_key)


def get_settings() -> Settings:
    return Settings(
        gemini_api_key=os.environ.get("GEMINI_API_KEY") or None,
        gemini_model=os.environ.get("GEMINI_MODEL", "gemini-1.5-flash"),
        max_source_chars=int(os.environ.get("MAX_SOURCE_CHARS", "40000")),
        generated_dir=os.environ.get("GENERATED_DIR", "generated"),
        environment=os.environ.get("ENVIRONMENT", "production"),
    )


settings = get_settings()
