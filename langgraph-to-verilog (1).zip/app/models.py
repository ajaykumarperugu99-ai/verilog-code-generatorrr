from __future__ import annotations

from typing import Literal
from pydantic import BaseModel, Field


class GenerateRequest(BaseModel):
    source_code: str = Field(..., min_length=1, description="LangGraph / LangChain Python source")
    requirements: str = Field("", description="Optional free-text hardware requirements")


class WorkflowNode(BaseModel):
    name: str
    kind: Literal["entry", "task", "decision", "terminal"] = "task"
    description: str = ""


class WorkflowEdge(BaseModel):
    source: str
    target: str
    condition: str | None = None  # None => unconditional


class UnsupportedComponent(BaseModel):
    name: str
    reason: str


class WorkflowAnalysis(BaseModel):
    graph_variable: str | None
    state_fields: list[str]
    nodes: list[WorkflowNode]
    edges: list[WorkflowEdge]
    decision_nodes: list[str]
    unsupported: list[UnsupportedComponent]
    analysis_method: Literal["ast", "ast+llm"]
    warnings: list[str] = []


class GeneratedFile(BaseModel):
    filename: str
    content: str
    kind: Literal["rtl", "testbench", "doc"]


class GenerateResponse(BaseModel):
    success: bool
    analysis: WorkflowAnalysis | None = None
    files: list[GeneratedFile] = []
    explanation: str = ""
    unsupported: list[UnsupportedComponent] = []
    error: str | None = None


class HealthResponse(BaseModel):
    status: str
    gemini_configured: bool
