"""
Server-side Gemini client.

The API key is read from app.config.settings and is never accepted from
a request. If the key is missing or the call fails, every function here
returns None / raises a caught, descriptive GeminiError so callers can
degrade gracefully instead of crashing the request.
"""

from __future__ import annotations

import json
import logging

from app.config import settings
from app.models import WorkflowAnalysis, WorkflowNode, WorkflowEdge

logger = logging.getLogger("verilog_gen.gemini")


class GeminiError(RuntimeError):
    pass


def _get_model():
    if not settings.gemini_configured:
        raise GeminiError(
            "GEMINI_API_KEY is not configured on the server. "
            "LLM-assisted analysis and explanations are unavailable; "
            "falling back to static analysis only."
        )
    try:
        import google.generativeai as genai
    except ImportError as exc:  # pragma: no cover
        raise GeminiError(
            "google-generativeai package is not installed on the server."
        ) from exc

    genai.configure(api_key=settings.gemini_api_key)
    return genai.GenerativeModel(settings.gemini_model)


_EXTRACTION_PROMPT = """You analyze LangGraph Python source code and extract its control-flow graph.
Respond with ONLY a single JSON object, no markdown fences, no commentary, matching exactly:
{{
  "state_fields": ["field1", "field2"],
  "nodes": [{{"name": "node_name", "kind": "entry|task|decision|terminal", "description": "short description"}}],
  "edges": [{{"source": "node_name", "target": "node_name", "condition": "condition_value_or_null"}}],
  "decision_nodes": ["node_name"],
  "unsupported": [{{"name": "component_name", "reason": "why it cannot become synthesizable RTL"}}]
}}
Rules:
- Use "START" and "END" as the entry/terminal node names.
- "unsupported" must list anything that cannot become ordinary synthesizable Verilog:
  LLM calls, arbitrary Python execution, network/file I/O, subprocess calls.
- Do not invent nodes or edges that are not in the source.

SOURCE CODE:
```python
{source}
```
"""


def extract_workflow_via_llm(source_code: str) -> WorkflowAnalysis:
    """Best-effort fallback extraction, used only when static AST
    analysis finds no StateGraph at all."""
    model = _get_model()
    prompt = _EXTRACTION_PROMPT.format(source=source_code[: settings.max_source_chars])

    try:
        response = model.generate_content(prompt)
        text = (response.text or "").strip()
        text = text.removeprefix("```json").removeprefix("```").removesuffix("```").strip()
        data = json.loads(text)
    except Exception as exc:  # noqa: BLE001
        raise GeminiError(f"Gemini extraction failed or returned invalid JSON: {exc}") from exc

    nodes = [WorkflowNode(**n) for n in data.get("nodes", [])]
    edges = [WorkflowEdge(**e) for e in data.get("edges", [])]

    return WorkflowAnalysis(
        graph_variable=None,
        state_fields=data.get("state_fields", []),
        nodes=nodes,
        edges=edges,
        decision_nodes=data.get("decision_nodes", []),
        unsupported=[UnsupportedComponentSafe(**u) for u in data.get("unsupported", [])],
        analysis_method="ast+llm",
        warnings=["Graph topology extracted via LLM fallback; verify against source before synthesis."],
    )


def UnsupportedComponentSafe(**kwargs):
    from app.models import UnsupportedComponent

    return UnsupportedComponent(**kwargs)


_EXPLANATION_PROMPT = """You write a short, precise hardware-architecture explanation.
Given this LangGraph workflow topology (nodes, edges, decisions) and the Verilog FSM
that was generated to represent it, write 4-8 sentences, in plain prose, explaining:
1) how each workflow stage maps to an FSM state,
2) how the two manager decisions ("store" vs "another") map to transitions,
3) which parts are represented as external hardware interfaces rather than true
   synthesizable logic, and why.
Do not use markdown headers or bullet lists. Do not repeat the JSON back verbatim.

WORKFLOW JSON:
{workflow_json}
"""


def generate_explanation(analysis: WorkflowAnalysis) -> str | None:
    """Returns None (not an exception) on any failure -- an explanation
    is a nice-to-have, never a hard requirement for generation to succeed."""
    try:
        model = _get_model()
        prompt = _EXPLANATION_PROMPT.format(workflow_json=analysis.model_dump_json(indent=2))
        response = model.generate_content(prompt)
        return (response.text or "").strip() or None
    except Exception as exc:  # noqa: BLE001
        logger.info("Gemini explanation generation skipped: %s", exc)
        return None
