"""
Agentic AI: LangGraph to Verilog Generator -- FastAPI application.

Run locally:
    uvicorn main:app --reload

Environment:
    GEMINI_API_KEY  (optional; enables LLM-assisted analysis fallback and
                      the natural-language explanation text)
"""

from __future__ import annotations

import io
import logging
import zipfile

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from app.config import settings
from app.models import GenerateRequest, GenerateResponse, HealthResponse, GeneratedFile
from app.workflow_analyzer import build_analysis
from app.verilog_generator import generate_verilog
from app import gemini_client

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("verilog_gen")

app = FastAPI(
    title="Agentic AI: LangGraph to Verilog Generator",
    description="Converts LangGraph / LangChain workflow control-flow into synthesizable Verilog HDL.",
    version="1.0.0",
)

app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")


@app.get("/")
async def index(request: Request):
    return templates.TemplateResponse(
        "index.html",
        {"request": request, "gemini_configured": settings.gemini_configured},
    )


@app.get("/api/health", response_model=HealthResponse)
async def health():
    return HealthResponse(status="ok", gemini_configured=settings.gemini_configured)


@app.post("/api/generate", response_model=GenerateResponse)
async def generate(req: GenerateRequest):
    source = req.source_code.strip()

    if not source:
        return JSONResponse(status_code=400, content=GenerateResponse(
            success=False, error="No source code was provided."
        ).model_dump())

    if len(source) > settings.max_source_chars:
        return JSONResponse(status_code=400, content=GenerateResponse(
            success=False,
            error=f"Source code exceeds the {settings.max_source_chars}-character limit for this deployment.",
        ).model_dump())

    # 1. Static (AST) analysis is always attempted first and is the
    #    source of truth for graph topology -- see workflow_analyzer.py.
    analysis = build_analysis(source)

    # 2. If AST analysis found nothing usable, try an LLM-assisted
    #    fallback -- only if Gemini is configured. If that also fails,
    #    return a clear, non-crashing error.
    if not analysis.nodes or not analysis.edges:
        if settings.gemini_configured:
            try:
                analysis = gemini_client.extract_workflow_via_llm(source)
            except gemini_client.GeminiError as exc:
                return JSONResponse(status_code=422, content=GenerateResponse(
                    success=False,
                    analysis=analysis,
                    error=(
                        "Could not find a LangGraph StateGraph in the supplied source, and the "
                        f"LLM-assisted fallback also failed: {exc}"
                    ),
                ).model_dump())
        else:
            return JSONResponse(status_code=422, content=GenerateResponse(
                success=False,
                analysis=analysis,
                error=(
                    "Could not find a LangGraph StateGraph(...) construction in the supplied "
                    "source (no add_node/add_edge calls detected). Server-side GEMINI_API_KEY "
                    "is not configured, so the LLM-assisted fallback analyzer is unavailable. "
                    "Paste the file that builds and compiles your graph."
                ),
            ).model_dump())

    # 3. Deterministic Verilog generation from the recovered topology.
    try:
        files, explanation = generate_verilog(analysis)
    except ValueError as exc:
        return JSONResponse(status_code=422, content=GenerateResponse(
            success=False, analysis=analysis, error=str(exc)
        ).model_dump())

    # 4. Optional: replace the deterministic explanation with a nicer
    #    LLM-written one. Never blocks or fails the request.
    if settings.gemini_configured:
        llm_explanation = gemini_client.generate_explanation(analysis)
        if llm_explanation:
            explanation = llm_explanation

    doc = GeneratedFile(
        filename="WORKFLOW_EXPLANATION.md",
        content=_render_explanation_doc(analysis, explanation, req.requirements),
        kind="doc",
    )

    return GenerateResponse(
        success=True,
        analysis=analysis,
        files=files + [doc],
        explanation=explanation,
        unsupported=analysis.unsupported,
    )


@app.post("/api/download-all")
async def download_all(req: GenerateRequest):
    """Regenerates the same files as /api/generate and returns them as
    a single .zip -- used by the 'Download All Files' button."""
    analysis = build_analysis(req.source_code)
    if not analysis.nodes or not analysis.edges:
        if settings.gemini_configured:
            try:
                analysis = gemini_client.extract_workflow_via_llm(req.source_code)
            except gemini_client.GeminiError as exc:
                return JSONResponse(status_code=422, content={"error": str(exc)})
        else:
            return JSONResponse(status_code=422, content={"error": "No workflow graph detected."})

    try:
        files, explanation = generate_verilog(analysis)
    except ValueError as exc:
        return JSONResponse(status_code=422, content={"error": str(exc)})

    if settings.gemini_configured:
        llm_explanation = gemini_client.generate_explanation(analysis)
        if llm_explanation:
            explanation = llm_explanation

    files = files + [GeneratedFile(
        filename="WORKFLOW_EXPLANATION.md",
        content=_render_explanation_doc(analysis, explanation, req.requirements),
        kind="doc",
    )]

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for f in files:
            zf.writestr(f.filename, f.content)
    buf.seek(0)

    return StreamingResponse(
        buf,
        media_type="application/zip",
        headers={"Content-Disposition": "attachment; filename=langgraph_to_verilog_output.zip"},
    )


def _render_explanation_doc(analysis, explanation: str, requirements: str) -> str:
    lines = ["# Workflow -> Hardware Architecture", "", explanation, ""]
    if requirements:
        lines += ["## Requested requirements", "", requirements, ""]
    lines += ["## Nodes", ""]
    for n in analysis.nodes:
        lines.append(f"- **{n.name}** ({n.kind}) {n.description}")
    lines += ["", "## Edges", ""]
    for e in analysis.edges:
        cond = f" [{e.condition}]" if e.condition else ""
        lines.append(f"- {e.source} -> {e.target}{cond}")
    if analysis.unsupported:
        lines += ["", "## Software-only components (not synthesized)", ""]
        for u in analysis.unsupported:
            lines.append(f"- **{u.name}**: {u.reason}")
    return "\n".join(lines)


if __name__ == "__main__":
    import os
    import uvicorn

    uvicorn.run("main:app", host="0.0.0.0", port=int(os.environ.get("PORT", 8000)))
