// tb_agent_top.v
// -----------------------------------------------------------------------
// Directed testbench exercising every workflow transition recovered
// from the analyzed source. Every external ack/result/sel is driven by
// a simple 1-cycle auto-responder here rather than real LLM/Python
// execution, per the synthesizable/non-synthesizable split documented
// in each interface module -- this checks FSM *sequencing*, not the
// software behavior behind each stage.
// -----------------------------------------------------------------------
`timescale 1ns/1ps

module tb_agent_top;

    reg clk = 0;
    reg rst_n = 0;
    reg start = 0;
    reg exit_req = 0;
    wire busy, done, error;
    wire [2:0] state_out;

    wire developer_ext_req;
    reg  developer_ext_ack = 1'b0;
    reg  [31:0] developer_ext_result = 32'd0;
    wire tester_ext_req;
    reg  tester_ext_ack = 1'b0;
    reg  [31:0] tester_ext_result = 32'd0;
    wire archiver_ext_req;
    reg  archiver_ext_ack = 1'b0;
    reg  [31:0] archiver_ext_result = 32'd0;
    wire task_input_ext_req;
    reg  task_input_ext_ack = 1'b0;
    reg  [0:0] task_input_ext_sel = 1'd0; // outcomes: 0=continue, 1=exit
    wire mgr_ext_req;
    reg  mgr_ext_ack = 1'b0;
    reg  [0:0] mgr_ext_sel = 1'd0; // outcomes: 0=store, 1=another

    always #5 clk = ~clk;

    // Generic stub: acknowledge every request exactly one clock later.
    // Real hardware/software would replace this block with genuine
    // LLM/Python execution results.
    always @(posedge clk) begin
        developer_ext_ack <= developer_ext_req; // 1-cycle stub response
        tester_ext_ack <= tester_ext_req; // 1-cycle stub response
        archiver_ext_ack <= archiver_ext_req; // 1-cycle stub response
        task_input_ext_ack <= task_input_ext_req; // 1-cycle stub response
        mgr_ext_ack <= mgr_ext_req; // 1-cycle stub response
    end

    agent_top u_agent_top (
        .clk       (clk),
        .rst_n     (rst_n),
        .start     (start),
        .exit_req  (exit_req),
        .busy      (busy),
        .done      (done),
        .error     (error),
        .state_out (state_out),
        .developer_ext_req    (developer_ext_req),
        .developer_ext_ack    (developer_ext_ack),
        .developer_ext_result (developer_ext_result),
        .tester_ext_req    (tester_ext_req),
        .tester_ext_ack    (tester_ext_ack),
        .tester_ext_result (tester_ext_result),
        .archiver_ext_req    (archiver_ext_req),
        .archiver_ext_ack    (archiver_ext_ack),
        .archiver_ext_result (archiver_ext_result),
        .task_input_ext_req (task_input_ext_req),
        .task_input_ext_ack (task_input_ext_ack),
        .task_input_ext_sel (task_input_ext_sel),
        .mgr_ext_req (mgr_ext_req),
        .mgr_ext_ack (mgr_ext_ack),
        .mgr_ext_sel (mgr_ext_sel),
        ._unused_terminator ()
    );

    integer i;

    initial begin
        $dumpfile("tb_agent_top.vcd");
        $dumpvars(0, tb_agent_top);

        // 1. Reset check: FSM must sit in IDLE (state_out == 0) under reset.
        rst_n = 0; start = 0;
        #20;
        if (state_out !== 0) $display("FAIL: reset did not return FSM to IDLE");
        else $display("PASS: reset -> IDLE");
        rst_n = 1;
        #10;

        // 2. Happy path: every decision defaults to outcome 0; let every
        //    stage complete and confirm the workflow reaches DONE.
        start = 1; #10; start = 0;
        for (i = 0; i < 40; i = i + 1) begin
            #10;
            if (done) begin
                $display("PASS: happy-path workflow reached DONE at t=%0t", $time);
                i = 999;
            end
        end
        if (i < 999) $display("FAIL: happy-path workflow never reached DONE within timeout");
        #20;

        // Alternate-branch scenario: task_input outcome index 1 ("exit")
        task_input_ext_sel = 1;
        rst_n = 0; #10; rst_n = 1; #10;
        start = 1; #10; start = 0;
        for (i = 0; i < 40; i = i + 1) begin
            #10;
            if (done) begin
                $display("PASS: alternate branch on task_input=\"exit\" still reached DONE at t=%0t", $time);
                i = 999;
            end
        end
        if (i < 999) $display("FAIL: alternate branch on task_input=\"exit\" never reached DONE");
        task_input_ext_sel = 0;
        #20;
        // Alternate-branch scenario: mgr outcome index 1 ("another")
        mgr_ext_sel = 1;
        rst_n = 0; #10; rst_n = 1; #10;
        start = 1; #10; start = 0;
        for (i = 0; i < 40; i = i + 1) begin
            #10;
            if (done) begin
                $display("PASS: alternate branch on mgr=\"another\" still reached DONE at t=%0t", $time);
                i = 999;
            end
        end
        if (i < 999) $display("FAIL: alternate branch on mgr=\"another\" never reached DONE");
        mgr_ext_sel = 0;
        #20;

        // 3. Early exit_req mid-workflow must force DONE, not hang.
        rst_n = 0; #10; rst_n = 1; #10;
        start = 1; #10; start = 0;
        #15;
        exit_req = 1;
        #10;
        exit_req = 0;
        if (done || error)
            $display("PASS: exit_req path reached DONE/ERROR at t=%0t", $time);
        else
            $display("INFO: exit_req path had not settled this cycle; check stage latency for this workflow");

        // 4. Invalid state recovery: force ERROR, confirm `start` recovers it.
        force u_agent_top.u_agent_controller.state = u_agent_top.u_agent_controller.ERROR;
        #10;
        if (!error) $display("FAIL: ERROR state did not assert error output");
        else $display("PASS: ERROR state asserts error output");
        release u_agent_top.u_agent_controller.state;
        rst_n = 0; #10; rst_n = 1; #10;
        start = 1; #10; start = 0;
        #10;
        if (error) $display("FAIL: FSM did not recover out of ERROR on start");
        else $display("PASS: FSM recovered from ERROR on start");

        #50;
        $display("Testbench complete.");
        $finish;
    end

endmodule
