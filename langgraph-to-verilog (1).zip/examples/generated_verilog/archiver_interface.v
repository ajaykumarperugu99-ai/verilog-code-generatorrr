// archiver_interface.v
// -----------------------------------------------------------------------
// Interface / handshake shell for the "archiver" workflow stage.
//
// NOT SYNTHESIZABLE AS TRUE COMBINATIONAL/SEQUENTIAL LOGIC: the actual
// behavior of this stage in the source workflow is data-dependent / software-defined and cannot be fixed at synthesis time.
// This module only implements the request/acknowledge handshake the
// controller needs; `result_valid`/`result_data` must be driven by
// external software (an embedded core, a co-processor, or -- in this
// project -- the FastAPI backend's own workflow engine) via whatever
// bus this SoC integration uses (AXI-Lite / Avalon-MM / a simple
// memory-mapped register file are all reasonable choices; none is
// implied here to keep this shell bus-agnostic).
// -----------------------------------------------------------------------
module archiver_interface #(
    parameter DATA_WIDTH = 32
) (
    input  wire clk,
    input  wire rst_n,

    input  wire start,             // pulsed by agent_controller
    output reg  done,              // pulse back to agent_controller
    output reg  busy,

    // external hardware/software co-processor bus (abstract)
    output reg                   ext_req,
    input  wire                  ext_ack,
    input  wire [DATA_WIDTH-1:0] ext_result
);

    reg pending;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            pending <= 1'b0;
            done    <= 1'b0;
            ext_req <= 1'b0;
        end else begin
            done <= 1'b0;
            if (start && !pending) begin
                pending <= 1'b1;
                ext_req <= 1'b1;
            end else if (pending && ext_ack) begin
                pending <= 1'b0;
                ext_req <= 1'b0;
                done    <= 1'b1;
            end
        end
    end

    always @(*) begin
        busy = pending;
    end

endmodule
