// agent_top.v
// -----------------------------------------------------------------------
// Top-level integration: agent_controller + one interface/decision
// module per workflow stage. External `*_ext_*` ports are where this
// design connects to whatever executes the software-only parts of the
// original workflow (LLM calls, Python execution, etc.) -- e.g. a
// microcontroller, an AXI/Avalon co-processor bus, or a simulation
// testbench driving canned responses.
// -----------------------------------------------------------------------
module agent_top (
    input  wire clk,
    input  wire rst_n,
    input  wire start,
    input  wire exit_req,
    output wire busy,
    output wire done,
    output wire error,
    output wire [2:0] state_out,

    output wire developer_ext_req,
    input  wire developer_ext_ack,
    input  wire [31:0] developer_ext_result,
    output wire tester_ext_req,
    input  wire tester_ext_ack,
    input  wire [31:0] tester_ext_result,
    output wire archiver_ext_req,
    input  wire archiver_ext_ack,
    input  wire [31:0] archiver_ext_result,
    output wire task_input_ext_req,
    input  wire task_input_ext_ack,
    input  wire [0:0] task_input_ext_sel,
    output wire mgr_ext_req,
    input  wire mgr_ext_ack,
    input  wire [0:0] mgr_ext_sel,
    output wire _unused_terminator
);

    assign _unused_terminator = 1'b0;

    wire developer_start, developer_done;
    wire tester_start, tester_done;
    wire archiver_start, archiver_done;
    wire task_input_eval, task_input_valid;
    wire [0:0] task_input_sel;
    wire mgr_eval, mgr_valid;
    wire [0:0] mgr_sel;

    agent_controller #(.STATE_WIDTH(3)) u_agent_controller (
        .clk       (clk),
        .rst_n     (rst_n),
        .start     (start),
        .exit_req  (exit_req),
        .busy      (busy),
        .done      (done),
        .error     (error),
        .developer_start (developer_start),
        .developer_done  (developer_done),
        .tester_start (tester_start),
        .tester_done  (tester_done),
        .archiver_start (archiver_start),
        .archiver_done  (archiver_done),
        .task_input_eval  (task_input_eval),
        .task_input_valid (task_input_valid),
        .task_input_sel   (task_input_sel[0:0]),
        .mgr_eval  (mgr_eval),
        .mgr_valid (mgr_valid),
        .mgr_sel   (mgr_sel[0:0]),
        .state_out (state_out)
    );

    developer_interface u_developer (
        .clk        (clk),
        .rst_n      (rst_n),
        .start      (developer_start),
        .done       (developer_done),
        .busy       (),
        .ext_req    (developer_ext_req),
        .ext_ack    (developer_ext_ack),
        .ext_result (developer_ext_result)
    );
    tester_interface u_tester (
        .clk        (clk),
        .rst_n      (rst_n),
        .start      (tester_start),
        .done       (tester_done),
        .busy       (),
        .ext_req    (tester_ext_req),
        .ext_ack    (tester_ext_ack),
        .ext_result (tester_ext_result)
    );
    archiver_interface u_archiver (
        .clk        (clk),
        .rst_n      (rst_n),
        .start      (archiver_start),
        .done       (archiver_done),
        .busy       (),
        .ext_req    (archiver_ext_req),
        .ext_ack    (archiver_ext_ack),
        .ext_result (archiver_ext_result)
    );
    task_input_interface u_task_input (
        .clk     (clk),
        .rst_n   (rst_n),
        .eval    (task_input_eval),
        .valid   (task_input_valid),
        .sel     (task_input_sel),
        .ext_req (task_input_ext_req),
        .ext_ack (task_input_ext_ack),
        .ext_sel (task_input_ext_sel)
    );
    manager_interface u_mgr (
        .clk     (clk),
        .rst_n   (rst_n),
        .eval    (mgr_eval),
        .valid   (mgr_valid),
        .sel     (mgr_sel),
        .ext_req (mgr_ext_req),
        .ext_ack (mgr_ext_ack),
        .ext_sel (mgr_ext_sel)
    );

endmodule
