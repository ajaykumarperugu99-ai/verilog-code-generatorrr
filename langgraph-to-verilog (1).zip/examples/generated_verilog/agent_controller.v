// agent_controller.v
// -----------------------------------------------------------------------
// Main FSM / workflow controller.
// Auto-generated from an analyzed LangGraph workflow. SYNTHESIZABLE.
//
// Each workflow "task" node becomes an FSM state that pulses a
// `<node>_start` request to its interface module and waits for a
// `<node>_done` acknowledge. Each "decision" node pulses `<node>_eval`,
// waits for `<node>_valid`, and branches on `<node>_sel`, which encodes
// the mutually-exclusive outcomes that node's routing function can
// return (e.g. manager_decision: 0=store, 1=another).
//
// Verilog-2001. Synchronous active-low reset.
// -----------------------------------------------------------------------
module agent_controller #(
    parameter STATE_WIDTH = 3
) (
    input  wire clk,
    input  wire rst_n,

    input  wire start,        // pulse: begin processing from IDLE
    input  wire exit_req,     // level: request early termination
    output reg  busy,
    output reg  done,
    output reg  error,

    output reg  developer_start,
    input  wire developer_done,
    output reg  tester_start,
    input  wire tester_done,
    output reg  archiver_start,
    input  wire archiver_done,
    output reg  task_input_eval,
    input  wire task_input_valid,
    input  wire [0:0] task_input_sel,
    output reg  mgr_eval,
    input  wire mgr_valid,
    input  wire [0:0] mgr_sel,

    output reg [STATE_WIDTH-1:0] state_out
);

    localparam [2:0] IDLE               = 3'd0;
    localparam [2:0] TASK_INPUT         = 3'd1;
    localparam [2:0] DEVELOPER          = 3'd2;
    localparam [2:0] TESTER             = 3'd3;
    localparam [2:0] MANAGER_DECISION   = 3'd4;
    localparam [2:0] ARCHIVER           = 3'd5;
    localparam [2:0] DONE               = 3'd6;
    localparam [2:0] ERROR              = 3'd7;

    reg [STATE_WIDTH-1:0] state, next_state;

    always @(*) begin
        next_state = state;
        developer_start = 1'b0;
        tester_start = 1'b0;
        archiver_start = 1'b0;
        task_input_eval  = 1'b0;
        mgr_eval  = 1'b0;
        error = 1'b0;

        case (state)
            IDLE: begin
                if (start) next_state = TASK_INPUT;
            end

            TASK_INPUT: begin
                task_input_eval = 1'b1;
                if (task_input_valid) begin
                    case (task_input_sel)
                        0: next_state = DEVELOPER;
                        1: next_state = DONE;
                        default: next_state = ERROR;
                    endcase
                end
            end
            DEVELOPER: begin
                developer_start = 1'b1;
                if (developer_done) next_state = TESTER;
            end
            TESTER: begin
                tester_start = 1'b1;
                if (tester_done) next_state = MANAGER_DECISION;
            end
            MANAGER_DECISION: begin
                mgr_eval = 1'b1;
                if (mgr_valid) begin
                    case (mgr_sel)
                        0: next_state = ARCHIVER;
                        1: next_state = TASK_INPUT;
                        default: next_state = ERROR;
                    endcase
                end
            end
            ARCHIVER: begin
                archiver_start = 1'b1;
                if (archiver_done) next_state = DONE;
            end

            DONE: begin
                next_state = IDLE;
            end

            ERROR: begin
                error = 1'b1;
                if (start) next_state = IDLE;
            end

            default: next_state = ERROR;
        endcase

        if (exit_req && state != IDLE && state != DONE) begin
            next_state = DONE;
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= IDLE;
        end else begin
            state <= next_state;
        end
    end

    always @(*) begin
        busy      = (state != IDLE) && (state != DONE) && (state != ERROR);
        done      = (state == DONE);
        state_out = state;
    end

endmodule
