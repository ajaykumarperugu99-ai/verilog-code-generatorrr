// manager_interface.v
// -----------------------------------------------------------------------
// Decision interface for the "manager_decision" workflow stage.
// Outcomes (encoded on sel): 0=store, 1=another
//
// The decision predicate itself (data-dependent / software-defined and cannot be fixed at synthesis time) is evaluated in
// software; this shell only exposes the synchronous handshake +
// result-select register that agent_controller branches on.
// -----------------------------------------------------------------------
module manager_interface (
    input  wire clk,
    input  wire rst_n,

    input  wire eval,               // pulsed by agent_controller
    output reg  valid,              // decision result is ready
    output reg  [1-1:0] sel,

    // external decision source (software-computed)
    output reg  ext_req,
    input  wire ext_ack,
    input  wire [1-1:0] ext_sel
);

    reg pending;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            pending <= 1'b0;
            valid   <= 1'b0;
            ext_req <= 1'b0;
            sel     <= {1{1'b0}};
        end else begin
            valid <= 1'b0;
            if (eval && !pending) begin
                pending <= 1'b1;
                ext_req <= 1'b1;
            end else if (pending && ext_ack) begin
                pending <= 1'b0;
                ext_req <= 1'b0;
                sel     <= ext_sel;
                valid   <= 1'b1;
            end
        end
    end

endmodule
