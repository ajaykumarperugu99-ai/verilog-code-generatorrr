"""
Reference LangGraph workflow: an autonomous dev/test/manager crew.

This file is the canonical example the converter is validated against.
It is not executed by the web app for its Python behavior — it is
analyzed (via AST + LLM-assisted extraction) purely to recover its
control-flow graph: nodes, edges, and conditional routing.
"""

from typing import TypedDict, List, Literal
from langgraph.graph import StateGraph, START, END
from langchain_google_genai import ChatGoogleGenerativeAI

# ---------------------------------------------------------------------------
# LLM
# ---------------------------------------------------------------------------

llm = ChatGoogleGenerativeAI(model="gemini-1.5-flash", temperature=0)


# ---------------------------------------------------------------------------
# State
# ---------------------------------------------------------------------------

class CrewState(TypedDict):
    messages: List[str]
    next_step: str
    code: str
    report: str


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------

def run_python_code(code: str) -> str:
    """Executes Python code and returns stdout or the raised error."""
    import io
    import contextlib

    buf = io.StringIO()
    try:
        with contextlib.redirect_stdout(buf):
            exec(code, {})
        return buf.getvalue() or "OK"
    except Exception as exc:  # noqa: BLE001
        return f"ERROR: {exc}"


def generate_test_cases(code: str) -> str:
    """Asks the LLM to propose test scenarios for the given code."""
    response = llm.invoke(f"Generate test cases for:\n{code}")
    return response.content


# ---------------------------------------------------------------------------
# Nodes
# ---------------------------------------------------------------------------

def task_input_node(state: CrewState) -> CrewState:
    """Accepts a new task from the user, or signals exit."""
    if state.get("next_step") == "exit":
        return {**state, "next_step": "exit"}
    return {**state, "next_step": "developer"}


def real_time_developer(state: CrewState) -> CrewState:
    """Generates or updates code for the current task."""
    code = state["code"]
    return {**state, "code": code, "next_step": "tester"}


def real_time_tester(state: CrewState) -> CrewState:
    """Runs the generated code and collects a test report."""
    result = run_python_code(state["code"])
    tests = generate_test_cases(state["code"])
    report = f"run={result}\ntests={tests}"
    return {**state, "report": report, "next_step": "manager_decision"}


def manager_decision_node(state: CrewState) -> CrewState:
    """Manager reviews the report and decides: store or request another task."""
    decision = "store" if "ERROR" not in state["report"] else "another"
    return {**state, "next_step": decision}


def archiver_node(state: CrewState) -> CrewState:
    """Persists the finished task and its report."""
    return {**state, "next_step": "done"}


# ---------------------------------------------------------------------------
# Routing functions
# ---------------------------------------------------------------------------

def route_from_task_input(state: CrewState) -> Literal["continue", "exit"]:
    return "exit" if state.get("next_step") == "exit" else "continue"


def route_from_manager(state: CrewState) -> Literal["store", "another"]:
    return state["next_step"]  # set by manager_decision_node to "store" or "another"


# ---------------------------------------------------------------------------
# Graph assembly
# ---------------------------------------------------------------------------

graph = StateGraph(CrewState)

graph.add_node("task_input", task_input_node)
graph.add_node("developer", real_time_developer)
graph.add_node("tester", real_time_tester)
graph.add_node("manager_decision", manager_decision_node)
graph.add_node("archiver", archiver_node)

graph.add_edge(START, "task_input")
graph.add_conditional_edges(
    "task_input",
    route_from_task_input,
    {"continue": "developer", "exit": END},
)
graph.add_edge("developer", "tester")
graph.add_edge("tester", "manager_decision")
graph.add_conditional_edges(
    "manager_decision",
    route_from_manager,
    {"store": "archiver", "another": "task_input"},
)
graph.add_edge("archiver", END)

app = graph.compile()
